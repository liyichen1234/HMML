from sklearn.ensemble import RandomForestClassifier
import json
import os
num = 10
with open('train_data100_codegraph.json','r') as f:
    train_data = json.load(f)

with open("codegraph_tokens_vocab_dict.json",'r') as f:
    vocab = json.load(f)

train = [data['features_content']['code_tokens'] for data in train_data]  
for features in train:
    for id in range(len(features)): 
        if features[id] =='<s>':
            middle = id
        if features[id] not in vocab.keys():
            features[id] = 0
        else:
            features[id] = vocab[features[id]]
for i in range(len(train)):
    if len(train[i]) >= 80:
        train[i] = train[i][:80]
    else:
        train[i] = train[i] + [0]*(80-len(train[i]))
    
label = [[data['labels_index'][num]] for data in train_data]

clf1 = RandomForestClassifier(n_estimators=40, max_depth=None,min_samples_split=2, random_state=0)
clf1.fit(train,label)


with open('test_data100_codegraph.json','r') as f:
    test_data = json.load(f)

test = [data['features_content']['code_tokens'] for data in test_data]  
for features in test:
    for id in range(len(features)): 
        if features[id] =='<s>':
            middle = id
        if features[id] not in vocab.keys():
            features[id] = 0
        else:
            features[id] = vocab[features[id]]
for i in range(len(test)):
    if len(test[i]) >= 80:
        test[i] = test[i][:80]
    else:
        test[i] = test[i] + [0]*(80-len(test[i]))
    
label = [[data['labels_index'][num]] for data in test_data]

class Evaluation:
    def __init__(self,true_positive,false_positive,false_negative):
        self.TP = true_positive
        self.FP = false_positive
        self.FN = false_negative

    
    def getP(self):
        if self.TP == 0:
            return 0
        return self.TP/(self.TP+self.FP)
    
    def getR(self):
        if self.TP == 0:
            return 0
        return self.TP/(self.TP+self.FN)
    
    def getF1(self):
        if self.TP == 0:
            return 0
        return 2*self.getP()*self.getR()/(self.getR()+self.getP())

evaluation_res = [Evaluation(0,0,0) for _ in range(11)]
all_eva = evaluation_res[-1]

for i in range(len(test)):
    predict = [clf1.predict([test[i]])[0].tolist()]
    nlabel = label[i]
  
    if  (predict[0] == 1 ):
        if nlabel == predict:
            all_eva.TP += 1
        else:
            all_eva.FP += 1
    if (nlabel[0] == 1 ):
        if nlabel != predict:
            all_eva.FN += 1 
            
    # if predict[0] == 1:
    #     for j in range(1,len(predict)):
    #         if predict[j] == 1:
    #             if predict[j] == nlabel[j]:
    #                 evaluation_res[j-1].TP += 1
    #             else:
    #                 evaluation_res[j-1].FP += 1

    # if nlabel[0] == 1:
    #     for j in range(1,len(nlabel)):
    #         if nlabel[j] == 1:
    #             if predict[j] != nlabel[j]:
    #                 evaluation_res[j-1].FN += 1

# for i in evaluation_res:
print("P:",all_eva.getP(),"R:",all_eva.getR(),"F:",all_eva.getF1())