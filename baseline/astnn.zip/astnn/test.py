import os
import json
import time
from tqdm import tqdm
import torch
import torch.nn as nn
from torch.nn.modules import module
from model import BatchProgramClassifier
import torch.optim as optim
from torch.autograd import Variable
from torch.nn.utils.rnn import pad_sequence
import warnings
warnings.filterwarnings('ignore')


class Evaluation:
    def __init__(self,true_positive,false_positive,false_negative):
        self.TP = true_positive
        self.FP = false_positive
        self.FN = false_negative

    
    def getP(self):
        if self.TP == 0:
            return 0
        return self.TP/(self.TP+self.FP)
    
    def getR(self):
        if self.TP == 0:
            return 0
        return self.TP/(self.TP+self.FN)
    
    def getF1(self):
        if self.TP == 0:
            return 0
        return 2*self.getP()*self.getR()/(self.getR()+self.getP())



def test():
    
    embedding_dim = 256
    encode_dim = embedding_dim
    hidden_dim = 250
    num_classes = 1  # 控制位
    device = 'cuda:0'
    batch_size = 100
    double_classfier = 0
    multi_classfier = 0
    num = 10
    evaluation_res = [Evaluation(0,0,0) for _ in range(11)]
    all_eva = evaluation_res[-1]
    with open("nodedict.json",'r') as f:
        vocab = json.load(f)
    vocab_size = len(vocab)

    model = BatchProgramClassifier(embedding_dim, hidden_dim, vocab_size, encode_dim, num_classes, batch_size, use_gpu=True, pretrained_weight=None).to(device)
    model.eval()
    checkpoint = torch.load('astnn_best'+str(num)+'.pth')
    model.load_state_dict(checkpoint['net'])

    with open("test_data.json",'r') as f:
        test_data = json.load(f)[:-44]
    test_size = len(test_data)

    for batch in tqdm(range(0,test_size,batch_size)):
        model.hidden = model.init_hidden()
        if batch+batch_size < test_size:
            test_batch = test_data[batch:batch+batch_size]
        else:
            test_batch = test_data[batch:]
        
        test = [data['features_content']for data in test_batch]
        model.batch_size = len(test)
       
        label = [[data['labels_index'][num]] for data in test_batch]
        input_batch = test
        output = model(input_batch)
        predict = output.detach().to('cpu').numpy().tolist()
        for i in predict:
            for j in range(len(i)):
                if i[j] >= 0.5:
                    i[j] = 1
                else:
                    i[j] = 0
        for i in range(len(label)):
            if label[i][0] == predict[i][0]:
                double_classfier += 1
            

            if  (predict[i][0] == 1):
                if label[i] == predict[i]:
                    all_eva.TP += 1
                else:
                    all_eva.FP += 1
            if (label[i][0] == 1):
                if label[i] != predict[i]:
                    all_eva.FN += 1 
            
          
    
    print("P:",all_eva.getP(),"R:",all_eva.getR(),"F:",all_eva.getF1())

test()
        
