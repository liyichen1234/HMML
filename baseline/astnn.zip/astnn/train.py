import os
import json
import time
import math
import torch
import torch.nn as nn
from model import BatchProgramClassifier
import torch.optim as optim
from torch.autograd import Variable
from tqdm import tqdm
import warnings
warnings.filterwarnings('ignore')

def train(model,train_data,optimizer,criterion,vocab,batch_size,device,num):
    model.train()
    train_size = len(train_data)
    epoch_loss = 0
    epoch_start = time.time()
    multi_classfier= 0
    double_classfier = 0
    for batch in tqdm(range(0,train_size,batch_size)):
        model.hidden = model.init_hidden()
        if batch+batch_size < train_size:
            train_batch = train_data[batch:batch+batch_size]
        else:
            train_batch = train_data[batch:]
            
        train = [data['features_content']for data in train_batch]
        model.batch_size = len(train)
        label = [[data['labels_index'][num]] for data in train_batch]
        input_batch = train
        target_batch = torch.tensor(Variable(torch.LongTensor(label)),dtype=torch.float32).to(device)
        optimizer.zero_grad()
        output = model(input_batch)
  
        output2 = output
        predict = output2.detach().to('cpu').numpy().tolist()
        for i in predict:
            for j in range(len(i)):
                if i[j] >= 0.5:
                    i[j] = 1
                else:
                    i[j] = 0
        for i in range(len(label)):
            if label[i][0] == predict[i][0]:
                double_classfier += 1
            
            
        loss = criterion(output,target_batch)
        loss.backward()
        epoch_loss += loss.item()
        optimizer.step()

    epoch_end = time.time()
    epoch_time = epoch_end-epoch_start
    ave_loss = epoch_loss/train_size
    double_acc = double_classfier/train_size
    return epoch_time,ave_loss,double_acc
    

def validate(model,dev_data,criterion,vocab,batch_size,device,num):
    model.eval()
    epoch_start = time.time()
    epoch_loss = 0
    double_classfier = 0
    multi_classfier = 0
    dev_size = len(dev_data)
    with torch.no_grad():
        for batch in tqdm(range(0,dev_size,batch_size)):
            if batch+batch_size < dev_size:
                dev_batch = dev_data[batch:batch+batch_size]
            else:
                dev_batch = dev_data[batch:]
            
            dev = [data['features_content'] for data in dev_batch]
            model.batch_size = len(dev)

            label = [[data['labels_index'][num]] for data in dev_batch]
            input_batch = dev
            target_batch = torch.tensor(Variable(torch.LongTensor(label)),dtype=torch.float32).to(device)
            output  = model(input_batch)
            output2 = output
            predict = output2.detach().to('cpu').numpy().tolist()
            for i in predict:
                for j in range(len(i)):
                    if i[j] >= 0.5:
                        i[j] = 1
                    else:
                        i[j] = 0
            for i in range(len(label)):
                if label[i][0] == predict[i][0]:
                    double_classfier += 1
               
            loss = criterion(output,target_batch)
            epoch_loss += loss.item()

    epoch_end = time.time()
    epoch_time = epoch_end-epoch_start
    ave_loss = epoch_loss/dev_size
    double_acc = double_classfier/dev_size
    return epoch_time,ave_loss,double_acc

def main():
    epoch = 6
    batch_size = 100
    embedding_dim = 256
    encode_dim = embedding_dim
    hidden_dim = 250
    num_classes = 1 # 控制位
    device = 'cuda:0'
    best_score = 0
    lr = 0.001
    num = 10
    with open("nodedict.json",'r') as f:
        vocab = json.load(f)
    vocab_size = len(vocab)

    model = BatchProgramClassifier(embedding_dim, hidden_dim, vocab_size, encode_dim, num_classes, batch_size, use_gpu=True, pretrained_weight=None).to(device)
    criterion = nn.BCELoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer,
                                                           mode="min",
                                                           factor=0.5,
                                                           patience=0)

    print("")                                   
    for epoch_num in range(epoch):
        with open("train_data.json",'r') as f:
            train_data = json.load(f)
        train_data = train_data[:83200]
        print("* Training epoch {}:".format(epoch_num))
        epoch_time,epoch_loss,double_acc = train(model,train_data,optimizer,criterion,vocab,batch_size,device,num) 
        print("-> Training time: {:.4f}s, loss = {:.4f}, bi_accuracy: {:.4f}%"
              .format(epoch_time, epoch_loss, (double_acc*100)))
        with open('dev_data.json','r') as f:
            dev_data = json.load(f)
        dev_data = dev_data[:int(len(dev_data)/batch_size)*batch_size]
        print("* Validating epoch {}:".format(epoch_num))
        epoch_time,epoch_loss,double_acc = validate(model,dev_data,criterion,vocab,batch_size,device,num) 
        print("-> Validating time: {:.4f}s, loss = {:.4f}, bi_accuracy: {:.4f}%"
              .format(epoch_time, epoch_loss, (double_acc*100)))
        print("")
        scheduler.step(double_acc)

        if double_acc > best_score:
            torch.save({
                'epoch':epoch_num,
                'net': model.state_dict()
            },'astnn_best'+str(num)+'.pth')

            best_score = double_acc
        
main()